const nodemailer = require("nodemailer");
const jwt = require('jsonwebtoken');
const { registratinTokenexpiresIn, confirmTokenSecret, serverConfig: { baseOrigin }, mailConfig } = require('../config.json');
const DBUtil = require('../helper/db');
const {
  confirmUserEmailString,
  checkPaswordString,
  getUsersString,
  getUserString,
  registerUserString,
  updateUserRoleString,
} = require('../helper/queries');

module.exports = {
  checkIfPasswordIsCorrect: (password, email) =>
    DBUtil.then(_ => _.query(checkPaswordString(email, `${password}`)))
      .then(({ recordset }) => recordset),
  users: () => DBUtil.then(_ => _.query(getUsersString))
    .then(({ recordset }) => recordset),
  registerUser: (email, password) => DBUtil.then(_ =>
    _.query(registerUserString(email, password)).then(() =>
      nodemailer.createTransport(mailConfig).sendMail({
        from: '"ROClujInnovCenter" <ROClujInnovCenter@accenture.com>',
        to: `${email}@accenture.com, zsolt.kiss@accenture.com , barna.bojthe-beyer@accenture.com`,
        subject: "Confirm your email address - submIX Team",
        html: `
        <html>
          <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style>
              .holder {
                display: flex;
                justify-content: space-evenly;
              }
            </style>
          </head>
          <body>
            <div class="holder">
              <div>
                <img src="${baseOrigin}/submIX_kis_at.gif">
              </div>
              <div>
                <h4>Welcome to submIX (Submit Idea)!</h4>
                <br><br><br>
                Please confirm your registration by clicking on 
                <a href="${baseOrigin}/confirm?${jwt.sign({ email }, confirmTokenSecret, { expiresIn: registratinTokenexpiresIn })}">this link</a> .
                <br>
                This URL is valid for 4 hours.
                Thank you for sharing your ideas for a better Accenture.
                <br><br>
                Best Regards,
                The submIX Team
              </div>
            </div>
          </body>
        </html>
        `
      }))
  ),
  getUser: email => DBUtil.then(_ => _.query(getUserString(email))),
  confirmUser: (email) => DBUtil.then(_ => _.query(confirmUserEmailString(email))),
  updateUserRole: (id, role) => DBUtil.then(_ => _.query(updateUserRoleString(id, role))).then(() => DBUtil.then(_ => _.query(getUsersString))
    .then(({ recordset }) => recordset))
}
