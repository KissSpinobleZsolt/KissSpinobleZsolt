const jwt = require('jsonwebtoken');
const { webTokenSecret } = require('../config.json');
const service = require('../services/post.service');

const posts = (req, res, next) => {
  const { headers: { auth }, method, body, url } = req;
  const token = auth && auth.split(' ')[1];
  if (token === 'null') return res.sendStatus(401);

  jwt.verify(token, webTokenSecret, async (err, user) => {
    if (err || !user) return res.sendStatus(403);
    const { role } = user
    switch (method) {
      case 'GET': {
        const posts = await service.getPosts();
        res.send(posts)
        break;
      }
      case 'POST': {
        if (role === 1) {
          res.sendStatus(403);
          break;
        }
        service.createPosts(body)
        res.sendStatus(201)
        break;
      }
      case 'PUT': {
        service.updatePosts(body);
        res.sendStatus(204)
        break;
      }
      case 'DELETE': {
        const splitedUrl = url.split("/");
        service.deletePosts(splitedUrl[splitedUrl.length - 1]);
        res.sendStatus(204)
        break;
      }
      default: break;
    }
    next();
  });
}

module.exports = posts