const jwt = require('jsonwebtoken');
const service = require('../services/user.service')

const { webTokenSecret, webTokenExpiresIn } = require('../config.json');

const login = (req, res, next) => {
  const { body: { email, password } } = req
  service.checkIfPasswordIsCorrect(password, email).then(result => {
    if (result.length) {
      const { id, role } = result[0]
      const token = jwt.sign(
        { id, email, role },
        webTokenSecret,
        { expiresIn: webTokenExpiresIn }
      )
      res.append('auth', `Bearer ${token}`).json({});
    } else (
      res.sendStatus(404)
    )
    next();
  }).catch(error => {
    if (error) console.error(error)
  })
}

module.exports = login