const logout = () => { }

module.exports = logout