const service = require('../services/user.service');

const users = (req, res, next) => {
  if (req.method === "GET") {
    service.users().then(response => {
      res.json(response)
      next()
    });
  } else return res.status(404)
}

module.exports = users