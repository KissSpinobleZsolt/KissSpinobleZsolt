const jwt = require('jsonwebtoken');
const { confirmTokenSecret } = require('../config.json');
const service = require('../services/user.service');

const confirm = (req, res, next) => {
  const { body: { token } } = req
  jwt.verify(token, confirmTokenSecret, (err, user) => {
    if (service.getUser(user.email)) return res.sendStatus(401)
    if (err || !user) return res.sendStatus(403);
    service.confirmUser(user.email).then(() => {
      res.sendStatus(201)
      next();
    }).catch(err => {
      console.log('err', err)
    });
  })
}

module.exports = confirm