const jwt = require('jsonwebtoken');
const { webTokenSecret } = require('../config.json');
const service = require('../services/user.service');

const user = (req, res, next) => {
  const { method, headers: { auth }, body } = req
  const token = auth && auth.split(' ')[1]
  if (token === 'null') return res.sendStatus(401)

  jwt.verify(token, webTokenSecret, (err, user) => {
    if (err || !user) return res.sendStatus(403);
    if (method === 'GET') {
      const { id, email, role } = user
      res.json({ id, email, role })
      next();
    } else if (method === 'PUT') {
      const { id, role } = body
      service.updateUserRole(id, role).then(response => {
        res.json(response)
        next()
      });
    }
  })
}
module.exports = user