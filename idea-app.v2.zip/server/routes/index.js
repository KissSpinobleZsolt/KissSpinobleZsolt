const confirm = require('./confirm.route');
const login = require('./loging.route');
const logout = require('./logout.route');
const posts = require('./posts.route');
const register = require('./register.route');
const user = require('./user.route');
const users = require('./users.route');

module.exports = { login, logout, posts, register, user, users, confirm };
