const service = require('../services/user.service');

const register = async (req, res, next) => {
  const { body: { email, password } } = req
  const { recordset } = await service.getUser(email)
  console.log(recordset, recordset.length)
  if (recordset.length) {
    res.sendStatus(403);
    next();
  }
  else {
    service.registerUser(email, password).then(() => {
      res.sendStatus(201);
      next();
    })
  }
}

module.exports = register