const sql = require('mssql/msnodesqlv8');
const { dbConfig } = require('../config.json');

module.exports = new sql.ConnectionPool(dbConfig).connect()
  .catch(e => console.error("Database Trouble!  ", e))