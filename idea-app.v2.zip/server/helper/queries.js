const sanitize = str => str.replace("'", "''");

const salt = 'ls;kdfhsdal;khlk;asdjflkasdjfl;ksjmpoucp8tpoJRC;LJEA;MIJ,CA;XFALJGVKDJ;GKLVJAS,C;LKF;CMLIRWHYLKDRFC.ASJ;FLVJEG;LM'
const createUserTable = `
DROP TABLE IF EXISTS users
CREATE TABLE users (
  id UNIQUEIDENTIFIER PRIMARY KEY default NEWID(),
  email VARCHAR(50) UNIQUE,
  userSecureIdentificationHash VARCHAR(100),
  role INT,
  isConfirmed INT
);`
const getUsersString = `
SELECT id, email, role FROM users
WHERE isConfirmed > 0;
`
const createUserString = ({ email, role }) => `
INSERT INTO users (
  email,
  userSecureIdentificationHash,
  role,
  isConfirmed
)
VALUES (
  '${email}',
  ENCRYPTBYPASSPHRASE('${salt}', 'wasd'),
  ${role},
  1
);
`
const registerUserString = (email, password) => `
INSERT INTO users (
  email,
  userSecureIdentificationHash,
  role,
  isConfirmed
)
VALUES (
  '${email}',
  ENCRYPTBYPASSPHRASE('${salt}', '${password}'),
  0,
  0
);
`
const confirmUserEmailString = (email) => `
UPDATE users
SET isConfirmed = 1
WHERE email = '${email}';
`
const getUserString = email => `
SELECT email FROM users
WHERE  email='${email}'
`
const checkPaswordString = (email, password) => `
SELECT id, role FROM users 
WHERE  email='${email}'
AND CONVERT(varchar(50), DECRYPTBYPASSPHRASE('${salt}', userSecureIdentificationHash))='${password}';
`
const createPostTable = `
DROP TABLE IF EXISTS posts
CREATE TABLE posts (
  id UNIQUEIDENTIFIER PRIMARY KEY default NEWID(),
  owner UNIQUEIDENTIFIER,
  mentor VARCHAR(50),
  title TEXT,
  situation TEXT,
  solution TEXT,
  benefits TEXT,
  status TEXT,
  standing TEXT,
  created DATETIME default getdate(),
  modified DATETIME 
);`
const getPostsString = `SELECT * FROM posts;`
const createPostString = ({
  owner,
  mentor,
  title,
  situation,
  solution,
  benefits,
  status,
  standing,
}) => `
INSERT INTO posts (
  owner, 
  mentor,
  title,
  situation,
  solution,
  benefits,
  status,
  standing,
  modified
)
VALUES (
  '${owner}',
  '${mentor}',
  '${sanitize(title)}',
  '${sanitize(situation)}',
  '${sanitize(solution)}',
  '${sanitize(benefits)}',
  '${status}',
  '${standing}',
  getdate()
);
`
const updatePostString = ({
  mentor,
  title,
  situation,
  solution,
  benefits,
  status,
  standing,
  id,
}) => `  
UPDATE posts
SET 
  mentor='${mentor}',
  title='${sanitize(title)}',
  situation='${sanitize(situation)}',
  solution='${sanitize(solution)}',
  benefits='${sanitize(benefits)}',
  status='${status}',
  standing='${standing}'
WHERE id = '${id}'; 
`
const deletePostString = (id) => `DELETE FROM posts WHERE id='${id}';`

const updateUserRoleString = (id, role) => `
UPDATE users
SET role = ${role}
WHERE id = '${id}';
`
module.exports = {
  checkPaswordString,
  confirmUserEmailString,
  createPostTable,
  createPostString,
  createUserTable,
  createUserString,
  deletePostString,
  getPostsString,
  getUserString,
  getUsersString,
  registerUserString,
  updatePostString,
  updateUserRoleString
}