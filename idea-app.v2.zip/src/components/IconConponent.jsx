import {
  StopOutlined,
  HourglassOutlined,
  SafetyCertificateOutlined,
  CheckSquareFilled,
  HourglassFilled,
  PlayCircleFilled
} from '@ant-design/icons';

export const IconConponent = (type) => {
  switch (type) {
    case 'CheckSquareFilled': return CheckSquareFilled
    case 'HourglassFilled': return HourglassFilled
    case 'PlayCircleFilled': return PlayCircleFilled
    case 'StopFilled': return StopOutlined
    case 'HourglassOutlined': return HourglassOutlined
    case 'SafetyCertificateFilled':
    default: return SafetyCertificateOutlined

  }
}