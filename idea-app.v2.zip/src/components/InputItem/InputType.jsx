import React from 'react';
import { useSelector } from 'react-redux';
import { Input, Select } from 'antd';
import { get, map, find, isEqual } from 'lodash';
import { 
  mentorsSelector,
  isAdminSelector, 
  isMentorSelector,
  userSelector,
} from '../../redux/selectors';

const { TextArea } = Input;

const InputType = ({
  userType,
  type,
  inpuType,
  placeholder,
  style,
  size,
  options,
  reduxed,
  ...rest
}) => {
  const { ideas, selectedIdeaId } = useSelector(state => state.ideas);
  const user = useSelector(userSelector);
  const mentors = useSelector(mentorsSelector);
  const isAdmin = useSelector(isAdminSelector);
  const isMentor = useSelector(isMentorSelector);
  const idea = find(ideas, { key: selectedIdeaId });
  const isOwner = isEqual(get(user, 'id'), get(idea, 'owner'));
  const heShould = userType === get(user, 'role')
  const disabled = () => {
    if(heShould) {
      if( userType === 0) {
        if (selectedIdeaId) {
          return !isOwner
        }
        return false
      }
      return false
    } else {
      if (isMentor) {
        if( userType === 0) {
          if (selectedIdeaId) {
            return !isOwner
          } return false
        }
        return userType === 1
      }
      return true
    }
  }
  const inputProps = {
    ...rest,
    placeholder,
    size,
    disabled: disabled(),
    style,
  };
  const selectOptions = reduxed ? map(mentors, ({id, email}) => ({value: id, label: email })) : map(options, value => ({ value, label: value }))
  const input = inpuType === "String"
    ? <Input {...inputProps} />
    : inpuType === "Text"
      ? <TextArea {...inputProps} />
      : <Select options={selectOptions} {...inputProps} />
  return !isAdmin && !isMentor ? userType === 0 && input : input
}

export default InputType