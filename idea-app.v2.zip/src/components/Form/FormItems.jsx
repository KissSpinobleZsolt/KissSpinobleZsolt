import React from 'react';
import { useSelector } from 'react-redux';
import { Form, Col } from 'antd';
import { get, find, map } from 'lodash';
import InputType from '../InputItem/InputType';
import { filteredByInputTypeSelector } from '../../redux/selectors'

const { Item } = Form;

const FormItems = () => {
  const filteredByInputType  = useSelector(filteredByInputTypeSelector);
  const { ideas, selectedIdeaId } = useSelector(state => state.ideas);
  const idea = find(ideas, { key: selectedIdeaId });
  return map(filteredByInputType, ({ key, colProp, itemProp, inputProps, userType }) => {
    return (
      <Col key={key} {...colProp}>
        <Item {...{ name: key, ...itemProp, initialValue: get(idea, key) }} >
          <InputType {...{ ...inputProps, userType }} />
        </Item>
      </Col >
    )
  })
}

export default FormItems
