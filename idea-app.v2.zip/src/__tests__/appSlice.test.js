import reducer, { toggleDrawer, toggleSearching } from '../redux/appSlice'

const previousState = {
  visible: false,
  isSearching: false,
  isWaitingSelected: false,
  isOpenSelected: false,
  caseSensitive: true,
  usersSettingsSelected: false,
}

test('should return the initial state', () => {
  expect(reducer(undefined, {})).toEqual(previousState)
})

test('should handle toggle visibility', () => {
  expect(reducer(previousState, toggleDrawer(previousState))).toEqual(
    {
      visible: true,
      isSearching: false,
      isWaitingSelected: false,
      isOpenSelected: false,
      caseSensitive: true,
      usersSettingsSelected: false,
    }
  )
})

test('should handle toggle isSearching', () => {
  expect(reducer(previousState, toggleSearching(previousState))).toEqual(
    {
      visible: false,
      isSearching: true,
      isWaitingSelected: false,
      isOpenSelected: false,
      caseSensitive: true,
      usersSettingsSelected: false,
    }
  )
})
