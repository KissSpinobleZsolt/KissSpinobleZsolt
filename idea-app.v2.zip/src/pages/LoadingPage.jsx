import { Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';

const antIcon = <LoadingOutlined className='LoadingIcon' spin />;

const LoadingPage = () => {
  return (
    <div className='LoadingPage'>
      <Spin indicator={antIcon} className="LoadingSpin"/>
    </div>
  )
}

export default LoadingPage