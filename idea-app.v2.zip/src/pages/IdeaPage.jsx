import React, { useEffect } from 'react';
import { Layout } from 'antd'
import { useDispatch, useSelector } from 'react-redux';
import { IdeaHeader, IdeaTable, IdeaFooter, FormDrawer, UsersDrawer } from '../components';
import { fetchIdeas, getAllUsers } from '../redux/actions';
import { isAdminSelector } from '../redux/userSlice';

const { Content } = Layout;

const IdeaPage = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchIdeas())
    dispatch(getAllUsers())
  }, [dispatch])
  const isAdmin = useSelector(isAdminSelector);
  return (
    <>
      <IdeaHeader />
      <Content >
        <IdeaTable className='Idea-table' />
      </Content>
      <IdeaFooter />
      <FormDrawer />
      {isAdmin && <UsersDrawer />}
    </>
  )
}

export default IdeaPage