import { createContext, useContext, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { fetchUser, requestLogin, requestLogout } from '../redux/userSlice';
import { registerUser } from './auth'

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(fetchUser())
  }, [dispatch]);

  const signin = (newUser, callback) => {
    return dispatch(requestLogin(newUser)).then(resp => {
      dispatch(fetchUser())
      callback(resp)
    })
  };

  const register = (newUser) => {
    return registerUser(newUser)
  };

  const signout = (callback) => {
    return dispatch(requestLogout()).then(callback)
  };
  
  const value = { signin, signout, register };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}