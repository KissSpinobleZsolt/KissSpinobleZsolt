import { map } from 'lodash';
import { makeFetch } from './communicator'
import { getToken } from './token';

const url = '/posts'
const makeCall = options => makeFetch(
  {
    ...options,
    headers: {
      auth: getToken()
    }
  }
);

const mapKey = data => map(data, (d, key) => ({
  ...d,
  key: key + 1
}))

export const fetchAll = async () => {

  const headers = {
    auth: getToken()
  }
  const options = {
    method: 'GET',
    url,
    headers
  }
  const { data } = await makeCall(options)
  return {
    data: mapKey(data)
  };
}

export const fetchUpdate = record => {
  const options = {
    method: 'PUT',
    url,
    data: JSON.stringify(record),
  }
  return makeCall(options)
}
export const fetchDelete = id => {
  const options = {
    method: 'DELETE',
    url: `${url}/${id}`
  }
  return makeCall(options)
}
export const fetchCreate = record => {
  const options = {
    method: 'POST',
    url,
    data: JSON.stringify(record),
  }
  return makeCall(options)
}

export const getUsers = () => {
  const options = {
    method: 'GET',
    url: '/users'
  }
  return makeCall(options)
}

export const register = (token) => {
  const options = {
    method: 'POST',
    url: '/confirm',
    data: JSON.stringify(token),
    timeout: 1000,
  }
  return makeCall(options)
}
export const updateUser = (id, role) => {
  const options = {
    method: 'PUT',
    url: '/user',
    data: JSON.stringify({ id, role }),
  }
  return makeCall(options)
}