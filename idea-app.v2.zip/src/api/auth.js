import { makeFetch } from './communicator'
import { getToken, removeToken, setToken } from './token';

export const checkUser = () => {
  const auth = getToken()
  return makeFetch({
    url: '/user',
    method: 'GET',
    headers: {
      auth,
    }
  }).catch(e => {
    if (auth && e) removeToken()
  })
};

export const login = (newUser) => {
  return makeFetch({
    method: 'POST',
    url: '/login',
    data: JSON.stringify(newUser),
  }).then(resp => {
    setToken(resp.headers.auth)
    return resp
  })
};

export const logout = () => {
  return makeFetch({
    url: '/logout',
    method: 'POST',
  })
};

export const registerUser = (newUser) => {
  return makeFetch({
    method: 'POST',
    url: '/register',
    data: JSON.stringify(newUser),
  })
};