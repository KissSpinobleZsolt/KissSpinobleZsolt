import { isEmpty } from "lodash"

export const removeToken = () => {
  localStorage.removeItem('token')
}

export const setToken = token => {
  localStorage.setItem('token', token.split(' ')[1])
}

export const getToken = () => {
  const token = localStorage.getItem('token')
  return `Bearer ${token}`
}
export const checkToken = () => {
  const token = localStorage.getItem('token')
  return !isEmpty(token)
}
