import benefits from "./benefits.json"
import created from "./created.json"
import mentor from "./mentor.json"
import modified from "./modified.json"
import owner from "./owner.json"
import situation from "./situation.json"
import solution from "./solution.json"
import standing from "./standing.json"
import status from "./status.json"
import title from "./title.json"

export {
  owner,
  title,
  solution,
  situation,
  benefits, 
  mentor,
  status,
  standing,
  created,
  modified,
}