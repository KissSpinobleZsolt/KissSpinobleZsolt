import { createSlice } from '@reduxjs/toolkit'

export const ideaSlice = createSlice({
  name: 'idea',
  initialState: {
    visible: false,
    isSearching: false,
    isWaitingSelected: false,
    isOpenSelected: false,
    caseSensitive: true,
    usersSettingsSelected: false,
  },
  reducers: {
    toggleDrawer: state => {
      state.visible = !state.visible
    },
    toggleUserDrawer: state => {
      state.usersSettingsSelected = !state.usersSettingsSelected
    },
    toggleSearching: state => {
      state.isSearching = !state.isSearching
    },
    toggleWaitingSelect: (state, action) => {
      state.isWaitingSelected = action.payload
    },
    toggleOpenSelect: (state, action) => {
      state.isOpenSelected = action.payload
    },
    toggleCaseSensitivity: state => {
      state.caseSensitive = !state.caseSensitive
    }
  },
})

export const { toggleDrawer, toggleSearching, toggleWaitingSelect, toggleOpenSelect, toggleCaseSensitivity, toggleUserDrawer } = ideaSlice.actions

export default ideaSlice.reducer