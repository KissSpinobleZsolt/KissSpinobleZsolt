import { configureStore } from '@reduxjs/toolkit';
import ideaReducer from './ideaSlice';
import appReducer from './appSlice';
import userReducer from './userSlice';
import fieldReducer from './fieldSlice'

export default configureStore({
  reducer: {
    ideas: ideaReducer,
    ui: appReducer,
    user: userReducer,
    fields: fieldReducer,
  },
})