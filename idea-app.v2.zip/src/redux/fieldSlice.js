import { filter, get, map, sortBy } from "lodash"
import { createSlice } from '@reduxjs/toolkit'
import * as fields from './docs'

export const fieldSets = sortBy(fields, 'index')

export const fieldSlice = createSlice({
  name: 'field',
  initialState: {
    fieldSets,
  },
  reducers: {},
});

export const fieldsetsSelector = state => get(state, ['fields','fieldSets'])

export const filteredByDisplaySelector = state => filter(fieldsetsSelector(state), 'display');
export const fieldSetsKeysSelector = state => map(filter(fieldsetsSelector(state), { userType: 0, display: true }), 'key');
export const filteredByInputTypeSelector = state => filter(fieldsetsSelector(state), 'inputProps.inpuType')

export default fieldSlice.reducer