import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { get, isEqual } from 'lodash'
import { checkUser, login, logout } from '../api/auth'
import { checkToken, removeToken } from '../api/token'

export const userSlice = createSlice({
  name: 'user',
  initialState: {
    isFetching: false,
    user: null,
    isAuthenticated: checkToken()
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchUser.pending, (state) => {
      state.isFetching = true
    })
    builder.addCase(fetchUser.fulfilled, (state, action) => {
      state.user = action.payload
      state.isFetching = false
    })
    builder.addCase(fetchUser.rejected, (state) => {
      state.user = null
      state.isFetching = false
      state.isAuthenticated = false
    })
    builder.addCase(requestLogin.pending, (state) => {
      state.isFetching = true
    })
    builder.addCase(requestLogin.fulfilled, (state, action) => {
      state.user = action.payload
      state.isAuthenticated = true
      state.isFetching = false
    })
    builder.addCase(requestLogin.rejected, (state) => {
      state.isAuthenticated = false
      state.isFetching = false
    })
    builder.addCase(requestLogout.pending, (state) => {
      removeToken()
      state.user = null
      state.isAuthenticated = false
      state.isFetching = false
    })
  },
})

export const fetchUser = createAsyncThunk('user/checkUser', async () => {
  const { data } = await checkUser()
  return data
})

export const requestLogin = createAsyncThunk('user/loginUser', async (user) => {
  const { data } = await login(user)
  return data
})

export const requestLogout = createAsyncThunk('user/logoutUser', async () => {
  await logout()
  return
})
export const userSelector = state => get(state, ['user', 'user'])
export const isAdminSelector = (state) => isEqual(get(userSelector(state), 'role'), 1)
export const isMentorSelector = (state) => isEqual(get(userSelector(state), 'role'), 2)

export default userSlice.reducer