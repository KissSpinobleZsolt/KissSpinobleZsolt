import React, { useEffect } from 'react';
import { Layout } from 'antd'
import { useDispatch } from 'react-redux';
import { IdeaHeader, IdeaTable, IdeaFooter, FormDrawer } from '../components';
import { fetchIdeas, getAllUsers } from '../redux/actions';

const { Content } = Layout;

const IdeaPage = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchIdeas())
    dispatch(getAllUsers())
  }, [dispatch])
  return (
    <>
      <IdeaHeader />
      <Content >
        <IdeaTable className='Idea-table' />
      </Content>
      <IdeaFooter />
      <FormDrawer />
    </>
  )
}

export default IdeaPage