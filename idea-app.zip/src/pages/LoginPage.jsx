import React, { useRef, useEffect, useState } from 'react';
import { Form, Input, Button, Typography, Row, Col, Space, Modal } from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useAuth } from '../api/authProvider';
import logo from '../logo.svg';
import submIX from '../submIX.png'

const { Title } = Typography
const { confirm, success, error } = Modal

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const auth = useAuth();
  const myRef = useRef();
  const from = location.state?.from?.pathname || "/";
  const [form] = Form.useForm();
  const { isAuthenticated } = useSelector(state => state.user)
  const [isRegistering, setIsRegistering] = useState(false)
  const showError = () => {
    error({
      content: 'Somthing went wrong, try again!',
    })
  }
  const showRegister = () => {
    success({
      content: 'You received a confirmation mail, please activate your user with the link, then you can log into submIX.',
      onOk() {
        setIsRegistering(!isRegistering)
      },
    })
  }
  const onFinish = ({email, password}) => {
    isRegistering
      ? auth.register({email, password}).then(showRegister).catch(showError)
      : auth.signin({email, password}, (status) => {
        status.payload
          ? navigate(from, { replace: true })
          : showError()
      }
      );
  }
  const toggleRegister = () => {
    !isRegistering ? showConfirm() : setIsRegistering(!isRegistering)
  }
  const showConfirm = () => {
    confirm({
      title: <h2>Welcome to <strong>submIX!</strong></h2>,
      icon: <ExclamationCircleOutlined />,
      content: (
        <div>
          <p>Register with your Accenture mail address,
          but <strong>USE A SEPARATE PASSWORD</strong>, not your Accenture (AD) one.</p>
          <h3>Password must contain: </h3>
          <ul>
              <li>a capital letter,</li>
              <li>two digits, </li>
              <li>and it should be at least 10 character long.</li>
          </ul>
        </div>
      ),
      onOk() {
      },
      cancelButtonProps: { style: { display: 'none' } },
      afterClose() {
        setIsRegistering(!isRegistering)
      }
    });
  }
  useEffect(() => {
    if (myRef && myRef.current) {
      const { input } = myRef.current
      input.focus()
    }
  }, [myRef])
  if (isAuthenticated) {
    return <Navigate to='/' state={{ from: location }} replace />
  }
  return (
    <>
      <div className='logoHolder'><img src={logo} className="header-logo" alt="logo" /></div>
      <Row justify='center' gutter={[8, 64]} style={{ marginTop: '30vh' }}>
        <Col span={12} offset={4}>
        <img src={submIX} className="header-submIX" alt="logo" />
          <Title style={{ color: 'white' }}>submIX {isRegistering ? "register" : 'login'}</Title>
        </Col>
        <Col span={24}>
          <Form
            name="login-register"
            form={form}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 6 }}
            onFinish={onFinish}
            autoComplete="off"
            scrollToFirstError
          >
            <Form.Item
              label="Email"
              name="email"
              rules={[{ required: true, message: 'Please input your email!' }]}
              className='login'
            >
              <Input ref={myRef} addonAfter='@accenture.com' className='select-with-after' />
            </Form.Item>
            <Form.Item
              label="Password"
              name="password"
              rules={[{ required: true, message: 'Please input your password!' }]}
              className='login'
              hasFeedback
            >
              <Input.Password />
            </Form.Item>
            {isRegistering && (
              <Form.Item
                name="confirm"
                label="Confirm Password"
                dependencies={['password']}
                className='login'
                hasFeedback
                rules={[
                  {
                    required: true,
                    message: 'Please confirm your password!',
                  },
                  {
                    min: 10,
                    message: 'It should be at least 10 character long'
                  },
                  {
                    pattern: '[a-z]',
                    message: 'Should have small carater'
                  },
                  {
                    pattern: '[A-Z]',
                    message: 'Should have capital carater'
                  },
                  {
                    pattern: /\d{2,}/,
                    message: 'Should have two digits'
                  },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (!value || getFieldValue('password') === value) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('The two passwords that you entered do not match!'));
                    },
                  }),
                ]}
              >
                <Input.Password />
              </Form.Item>
            )}
            <Form.Item wrapperCol={{ offset: 8, span: 6 }}>
              <Space size={60}>
                <Button htmlType="submit">
                  {isRegistering ? 'Register' : 'Login'}
                </Button>
                <Button onClick={toggleRegister} >
                  {isRegistering ? 'Cancel' : 'Register'}
                </Button>
              </Space>
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </>
  )
}

export default LoginPage