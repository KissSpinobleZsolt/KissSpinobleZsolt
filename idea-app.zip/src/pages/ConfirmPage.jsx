import { Button, Spin, Typography } from "antd";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom"
import { register } from "../api/dataProvider";

const { Title } = Typography;

const ConfirmPage = () => {
  const navigate = useNavigate()
  const { search } = useLocation();
  const [loading, setLoading] = useState(true)
  const [isConfimed, setIsConfimed] = useState(true)

  useEffect(() => {
    register({ token: search.slice(1) }).then(resp => {
      setIsConfimed(true)
    }).catch(err => {
      setIsConfimed(false)
    }).finally(() => {
      setLoading(false)
    });
    return false
  }, [search])

  return (
    <div>
      <Button
        size="large"
        type="link"
        onClick={() => { navigate('/', { replace: true }) }}
        style={{ color: 'white', border: '1px solid' }}
      > Go Back to root</Button>
      {loading
        ? <Spin />
        : <Title style={{ color: 'white', margin: '1em' }}>
          {isConfimed
            ? 'User activated, you may now log in'
            : 'Something went wrong please contact your Sysadmin!'}
        </Title>
      }
    </div>
  )
}

export default ConfirmPage