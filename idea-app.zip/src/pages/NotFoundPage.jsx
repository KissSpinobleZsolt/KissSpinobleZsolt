import { Button } from "antd"
import { useNavigate } from "react-router-dom"

const NotFoundPage = () => {
  const navigate = useNavigate()
  return (
    <div>
      <Button
        type="link"
        onClick={() => { navigate('/', { replace: true }) }}
        style={{ color: 'white' }}
      > Go Back to root</Button>
      Page not found
    </div>
  )
}

export default NotFoundPage