const jwt = require('jsonwebtoken');
const { webTokenSecret } = require('../config.json');

const user = (req, res, next) => {
  const { headers: { auth } } = req
  const token = auth && auth.split(' ')[1]
  if (token === 'null') return res.sendStatus(401)

  jwt.verify(token, webTokenSecret, (err, user) => {
    if (err || !user) return res.sendStatus(403);
    const { id, email, role } = user
    res.json({ id, email, role })
    next();
  })
}
module.exports = user