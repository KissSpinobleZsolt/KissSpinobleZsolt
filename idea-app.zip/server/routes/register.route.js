const service = require('../services/user.service');

const register = async (req, res, next) => {
  const { body: { email, password } } = req
  const { recordset } = await service.getUser(email)
  if (recordset[0]?.email) {
    return res.status(403)
  }
  else {
    service.registerUser(email, password)
    res.status(201)
  }
  next()
}
module.exports = register