const DBUtil = require('./db');
const {
  createUserTable,
  createPostTable,
  createUserString,
  createPostString,
} = require('./queries');
const { map } = require('lodash');
const users = require('./users.json');
const posts = require('./posts.json');

const getOwner = `SELECT id FROM users WHERE role = 0`;
const getMentor = `SELECT id FROM users WHERE role = 2`;

const createUsers = () => map(users, user =>
  DBUtil.then(_ => _.query(createUserString(user)))
)
const createPost = async () => {
  const owner = await DBUtil.then(_ => _.query(getOwner))
  const mentor = await DBUtil.then(_ => _.query(getMentor))
  map(posts, rawpost =>
    DBUtil.then(_ => _.query(createPostString({
      ...rawpost,
      owner: owner.recordset[0].id,
      mentor: mentor.recordset[0].id,
    })))
  )
}
DBUtil.then(_ => _.query(createUserTable))
  .then(() =>
    DBUtil.then(_ => _.query(createPostTable)))
  .then(createUsers)
  .then(createPost)
