const DBUtil = require('../helper/db');
const { getPostsString, updatePostString, createPostString, deletePostString } = require('../helper/queries');

module.exports = {
  getPosts: () => DBUtil.then(_ => _.query(getPostsString))
    .then(({ recordset }) => recordset),
  createPosts: (post) => DBUtil.then(_ => _.query(createPostString(post))),
  updatePosts: (post) => DBUtil.then(_ => _.query(updatePostString(post))),
  deletePosts: (id) => DBUtil.then(_ => _.query(deletePostString(id))),
}