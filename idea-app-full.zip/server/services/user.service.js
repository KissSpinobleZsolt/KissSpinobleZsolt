const nodemailer = require("nodemailer");
const jwt = require('jsonwebtoken');
const { registratinTokenexpiresIn, confirmTokenSecret, serverConfig: { baseOrigin } } = require('../config.json');
const DBUtil = require('../helper/db');
const { confirmUserEmailString, checkPaswordString, getUsersString, registerUserString } = require('../helper/queries');

const sendMail = async (mail, token) => {
  const transporter = nodemailer.createTransport({
    host: "FRAext.SMTP.Accenture.com",
    port: 25,
    secure: true,
  });

  await transporter.sendMail({
    from: '"ROClujInnovCenter" <ROClujInnovCenter@accenture.com>',
    to: `${mail}@accenture.com, zsolt.kiss@accenture.com , barna.bojthe-beyer@accenture.com`,
    subject: "Confirm your email address - submIX Team",
    html: `
    <div style="display: flex; justify-content: space-evenly;">
      <div>
        <img src="cid:unique@accenture.com">
      </div>
      <div>
        <h4>Welcome to submIX (Submit Idea)!</h4>
        </br></br></br>
        Please confirm your registration by clicking on <a href="${baseOrigin}/confirm?${token}">this link</a> .
        </br>
        This URL is valid for 4 hours.
        Thank you for sharing your ideas for a better Accenture.
        </br></br>
        Best Regards,
        The submIX Team
      </div>
    </div>
  `,
    attachments: [{
      filename: 'submIX_kis_at.gif',
      path: '../../public',
      cid: 'unique@accenture.com'
    }]
  });
}

module.exports = {
  checkIfPasswordIsCorrect: (password, email) =>
    DBUtil.then(_ => _.query(checkPaswordString(email, `${password}`)))
      .then(({ recordset }) => recordset),
  users: () => DBUtil.then(_ => _.query(getUsersString))
    .then(({ recordset }) => recordset),
  registerUser: (email, password) => DBUtil.then(_ => _.query(registerUserString(email, password)))
    .then(() => {
      const token = jwt.sign(
        { email },
        confirmTokenSecret,
        { expiresIn: registratinTokenexpiresIn }
      )
      console.log(token)
      return sendMail(email, token)
    }),
  confirmUser: (email) => DBUtil.then(_ => _.query(confirmUserEmailString(email)))
}
