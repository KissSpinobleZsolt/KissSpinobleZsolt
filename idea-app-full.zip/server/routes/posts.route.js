const jwt = require('jsonwebtoken');
const { webTokenSecret } = require('../config.json');
const postService = require('../services/post.service');

const posts = (req, res, next) => {
  const { headers: { auth }, method, body, url } = req;
  const token = auth && auth.split(' ')[1];
  if (token === 'null') return res.sendStatus(401);

  jwt.verify(token, webTokenSecret, async (err, user) => {
    if (err || !user) return res.sendStatus(403);
    const { id, role } = user
    switch (method) {
      case 'GET': {
        const posts = await postService.getPosts();
        res.send(posts)
        break;
      }
      case 'POST': {
        if (role === 0) {
          res.sendStatus(403);
          break;
        }
        postService.createPosts(body)
        res.sendStatus(201)
        break;
      }
      case 'PUT': {
        const record = await postService.updatePosts(body)
        console.log('put', id, role, body, record)
        res.sendStatus(204)
        break;
      }
      case 'DELETE': {
        const splitedUrl = url.split("/");
        const record = await postService.deletePosts(splitedUrl[splitedUrl.length - 1]);
        console.log('delete', id, role, record);
        res.sendStatus(204)
        break;
      }
      default: break;
    }
    next();
  });
}

module.exports = posts