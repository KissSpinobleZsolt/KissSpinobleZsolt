const jwt = require('jsonwebtoken');
const service = require('../services/user.service')

const { webTokenSecret, webTokenExpiresIn } = require('../config.json');

const login = (req, res, next) => {
  const { body: { email, password } } = req
  service.checkIfPasswordIsCorrect(password, email).then(result => {
    if (result.length) {
      const { id, role } = result[0]
      const token = jwt.sign(
        { id, email, role },
        webTokenSecret,
        { expiresIn: webTokenExpiresIn }
      )
      res.append('auth', `Bearer ${token}`).json({});
    } else (
      res.status(404)
    )
    next();
  }).catch(error => {
    if (error) console.error(error)
  })
}

const register = async (req, res, next) => {
  const { body: { email, password } } = req
  const r = await service.registerUser(email, password)
  console.log(r)
  res.status(201)
  next()
}

const logout = () => { }

module.exports = { login, logout, register }