const jwt = require('jsonwebtoken');
const { webTokenSecret, confirmTokenSecret } = require('../config.json');
const service = require('../services/user.service');

const users = (req, res, next) => {
  if (req.method === "GET") {
    service.users().then(response => {
      res.json(response)
      next()
    });
  } else return res.status(404)
}

const user = (req, res, next) => {
  const { headers: { auth } } = req
  const token = auth && auth.split(' ')[1]
  if (token === 'null') return res.sendStatus(401)

  jwt.verify(token, webTokenSecret, (err, user) => {
    if (err || !user) return res.sendStatus(403);
    const { id, email, role } = user
    res.json({ id, email, role })
    next();
  })
}

const confirm = (req, res, next) => {
  const { body: { token } } = req
  jwt.verify(token, confirmTokenSecret, (err, user) => {
    console.log(user)
    if (err || !user) return res.sendStatus(403);
    service.confirmUser(user.email).then(() => {
      res.sendStatus(201)
      next();
    }).catch(err => {
      console.log('err', err)
    });
  })
}
module.exports = { user, users, confirm }