
const { login, logout, register } = require('./loging.route');
const posts = require('./posts.route');
const { users, user, confirm } = require('./users.route');

module.exports = { login, logout, posts, register, user, users, confirm };
