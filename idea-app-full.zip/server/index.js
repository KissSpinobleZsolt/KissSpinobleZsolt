
const express = require('express');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const { user, users, login, logout, posts, register, confirm } = require('./routes/index');
const { webTokenSecret, serverConfig: { PORT, baseOrigin } } = require('./config.json');

function checkToken(req, res, next) {
  const { headers: { auth } } = req
  const token = auth && auth.split(' ')[1]
  if (token === 'null') return res.sendStatus(401)

  jwt.verify(token, webTokenSecret, (err, user) => {
    if (err) return res.sendStatus(403);
    next();
  })
}

const buildPath = path.resolve(__dirname, '../build');
const origin = process.env.NODE_ENV === 'development ' ? 'http://localhost:3002' : baseOrigin;
const corsOptions = {
  origin,
  optionsSuccessStatus: 200,
  credentials: true,
  exposedHeaders: ['auth'],
  allowedHeaders: ['auth', 'Content-Type', 'Accept']
};
const app = express();

app.use(bodyParser.json());
app.use(express.static(buildPath));
app.use(express.static(path.resolve(__dirname, '../public')));
app.use(cors(corsOptions));

app.post('/api/login', login);
app.post('/api/logout', logout);
app.post('/api/register', register);
app.get('/api/user', user);
app.all('/api/posts*', posts);
app.all('/api/users', checkToken, users);
app.post('/api/confirm', confirm);
app.get('/login', (req, res) => {
  res.sendFile(path.join(buildPath + '/index.html'));
});
app.get('/confirm', (req, res) => {
  res.sendFile(path.join(buildPath + '/index.html'));
});
app.listen(3001, () => {
  console.log('server started on port: ' + PORT)
})