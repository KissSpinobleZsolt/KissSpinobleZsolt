import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useSelector } from 'react-redux';
import LoadingPage from "../pages/LoadingPage";

const RequireAuth = ({ children }) => {
  const { isAuthenticated, isFetching } = useSelector(state => state.user)
  const location = useLocation();
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  if (isFetching) {
    return <LoadingPage />
  }

  return children;
}
export default RequireAuth;
