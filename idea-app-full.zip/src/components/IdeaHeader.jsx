import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Col, Dropdown, Layout, Menu, Row, Button, Input, Popover, Checkbox } from 'antd';
import {
  PlusOutlined,
  SearchOutlined,
  UserOutlined,
  StarFilled,
  HourglassFilled,
  HourglassOutlined,
  StarOutlined
} from '@ant-design/icons/lib/icons';
import { get } from 'lodash';
import { useAuth } from '../api/authProvider';
import logo from '../submIX.png';
import { toggleDrawer, toggleWaitingSelect, toggleOpenSelect, toggleCaseSensitivity } from '../redux/appSlice';
import { searchIdeas } from '../redux/ideaSlice';
import { userSelector } from '../redux/selectors'

const { Header } = Layout;

const IdeaHeader = () => {
  const auth = useAuth();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    ui: { caseSensitive },
    ideas: { searchedIdeas }
  } = useSelector(state => state);
  const user = useSelector(userSelector);
  const props = {
    onClick: () => {
      dispatch(toggleCaseSensitivity())
    },
  };
  return (
    <Header className='LayoutHeader'>
      <Row justify='space-between'>
        <Col span={4}>
          <img src={logo} className="header-submix" alt="logo" />
        </Col>
        <Col span={8}>
          <Input
            allowClear
            className="searchField"
            prefix={<SearchOutlined />}
            defaultValue={searchedIdeas}
            suffix={
              <Popover content={`Select Case Sensitivity current is ${caseSensitive ? 'ON' : 'OFF'}`}>{
                caseSensitive ? <StarFilled {...props} /> : <StarOutlined {...props} />
              }</Popover>
            }
            onChange={({ target }) => {
              dispatch(searchIdeas(target.value))
            }}
          />
        </Col>
        <Col span={2} offset={1}>{
          get(user,'role') !== 1 && (
            <Button onClick={() => {
              dispatch(toggleDrawer())
            }} icon={<PlusOutlined />}>
              ADD IDEA
            </Button>)}
        </Col>
        <Col span={5}>
          <Row >
            <Col span={10}>
              <Checkbox onChange={e => {
                dispatch(toggleWaitingSelect(e.target.checked ? { key: "standing", value: "Waiting for approval" } : false))
              }}><HourglassOutlined />{'waiting?'}</Checkbox>
            </Col>
            <Col span={10} offset={2}>
              <Checkbox onChange={e => {
                dispatch(toggleOpenSelect(e.target.checked ? { key: "status", value: "Open" } : false))
              }}><HourglassFilled />{'open?'}</Checkbox>
            </Col>
          </Row>
        </Col>
        <Col span={4} className='extraClass'>
          <Dropdown overlay={(
            <Menu >
              <Menu.Item key='logout' onClick={() => {
                auth.signout(() => {
                  return navigate('/login', { replace: true })
                })
              }}>
                Logout
              </Menu.Item>
            </Menu>
          )} placement='bottomCenter' >
            <Button icon={<UserOutlined />}  style={{
              left: '50%'
            }}>
              {get(user, 'email')}
            </Button>
          </Dropdown>
        </Col>
      </Row>
    </Header >
  )
}

export default IdeaHeader