import React from 'react';

const MenuContent = ({ currentContnet }) => {
  return <div style={{ margin: '8px 8px 0 8px' }}>{currentContnet}</div>
};

export default MenuContent;