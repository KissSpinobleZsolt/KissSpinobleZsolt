import React, { useRef, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from 'dayjs';
import { Table, Popconfirm, Divider, Input, Tooltip } from 'antd';
import Icon, {
  DeleteOutlined,
  EditOutlined,
  FilterFilled,
  SearchOutlined,
} from '@ant-design/icons';
import Highlighter from 'react-highlight-words';
import { isEqual, map, get, filter, chain, isEmpty, find } from 'lodash';
import FuzzySearch from 'fuzzy-search';
import DeatilMenu from '../Menu/DeatilMenu';
import { IconConponent } from '../IconConponent'
import { deleteIdea, selectIdeaId, toggleDrawer } from '../../redux/actions';
import { 
  isAdminSelector, 
  isMentorSelector, 
  mentorsSelector, 
  filteredByDisplaySelector,
  userSelector,
  fieldsetsSelector,
 } from '../../redux/selectors';

const IdeaTable = () => {
  let searchInput = useRef();
  const dispatch = useDispatch();
  const {
    ui: { isWaitingSelected, isOpenSelected, caseSensitive },
    ideas: { ideas, searchedIdeas, users }
  } = useSelector(state => state);
  const user = useSelector(userSelector);
  const fieldSets = useSelector(fieldsetsSelector)
  const mentors = useSelector(mentorsSelector);
  const isAdmin = useSelector(isAdminSelector);
  const isMentor = useSelector(isMentorSelector);
  const filteredByDisplay = useSelector(filteredByDisplaySelector);
  const [state, setState] = useState({
    searchText: '',
    searchedColumn: '',
  });
  const makeRestColumnProps = ({ type, format, inpuType, options, key, icons, reduxed }) => {
    switch(type) {
      case "Date": {
        return {
          render: (value) => dayjs(value).format(format),
          sorter: (a, b) => dayjs(get(a, key)).diff(dayjs(get(b, key))),
        }
      }
      case "String": {
        if (inpuType === 'Select' || inpuType === null) {
          return {
            filterIcon: filtered => <Tooltip title={'Click to filter'}><FilterFilled style={{ color: filtered ? '#1890ff' : undefined }} /></Tooltip>,
            filters: reduxed ? map(key === "mentor" ? mentors : users, ({id, email}) => ({value: id, text: email})) : map(options, value => ({ value, text: value })),
            onFilter: (value, record) => reduxed ? get(record, key) === value : record[key].indexOf(value) === 0,
            render: (value) => {
              const text = reduxed ? find(key === "mentor" ? mentors : users, { id: value })?.email : value
              if (icons) {
                const settings = chain(icons).find(value).get(value).value()
                return <Tooltip title={value}><Icon component={IconConponent(settings)} /></Tooltip>
              }
              return text
            }
          }
        } return {
          ellipsis: true,
          filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
            <div style={{ padding: 8 }}>
              <Input
                ref={node => {
                  searchInput = node;
                }}
                placeholder={`Search ${key}`}
                value={selectedKeys[0]}
                onChange={e => {
                  setSelectedKeys(e.target.value ? [e.target.value] : [])
                  setState({
                    searchText: e.target.value,
                    searchedColumn: key,
                  });
                  confirm({ closeDropdown: false });
                }}
                allowClear
              />
            </div>
          ),
          filterIcon: filtered => <Tooltip title={'Click to search'}><SearchOutlined style={{ color: filtered ? '#1890ff' : undefined }} /></Tooltip>,
          onFilter: (value, record) =>
            record[key]
              ? record[key].toString().toLowerCase().includes(value.toLowerCase())
              : '',
          onFilterDropdownVisibleChange: visible => {
            if (visible) {
              setTimeout(() => {
                searchInput.focus()
              }, 100)
            }
          },
          render: value => {
            const text = reduxed ? find(users, { id: value })?.email : value
            return state.searchedColumn === key ? (
              <Highlighter
                highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
                searchWords={[state.searchText]}
                autoEscape
                textToHighlight={text ?? ''}
              />
            ) : (
              text
            )
          },
  
        }
      }
      default: {
        console.log('default')
        break
      }
    }
    return {}
  };
  const sortByUserType = userType => filter(fieldSets, { userType })
  const data = filter(ideas, idea => {
    const iTis = source => isEqual(get(idea, source.key), source.value)
    if (isWaitingSelected && !isOpenSelected) {
      return iTis(isWaitingSelected)
    } 
    if (!isWaitingSelected &&isOpenSelected) {
      return iTis(isOpenSelected)
    }
    if (isWaitingSelected && isOpenSelected) {
      return iTis(isWaitingSelected) && iTis(isOpenSelected)
    }
    return true
  })
  const searcher = new FuzzySearch(data, map(sortByUserType(0), 'key'), {
    caseSensitive,
  });

  const tableProps = {
    size: "large",
    bordered: true,
    className: 'Idea-table',
    columns: [
      ...map(filteredByDisplay, (field) => {
        const { title, key, columnProps, inputProps, width } = field
        return {
          onHeaderCell: (column) => {
            return {
              width: column.width,
            }
          },
          title,
          dataIndex: key,
          key,
          width: width || 100,
          ...columnProps,
          ...makeRestColumnProps({ ...inputProps, key }),
        }
      }),
      {
        title: 'Actions',
        width: 100,
        align: 'center',
        key: 'actions',
        dataIndex: 'actions',
        fixed: 'right',
        render: (_, record) => {
          if (user) {
            const isOwner = isEqual(get(user, 'id'), get(record, 'owner'))
            const heIstheMentor = isEqual(get(record, 'mentor'), get(user, 'id'))
            if (isOwner || isAdmin || isMentor) {
              return (
                <>
                  {(isAdmin || isOwner || heIstheMentor) && (
                    <Tooltip title={'Edit'}>
                      <EditOutlined 
                        onClick={() => {
                          dispatch(selectIdeaId(record.key))
                          dispatch(toggleDrawer())
                        }} 
                      />
                      </Tooltip>
                  )}
                  {(isOwner || isAdmin) && (
                    <>
                      <Divider type="vertical" />
                      <Popconfirm title="Sure to Delete?" 
                        onConfirm={() => {
                          dispatch(deleteIdea(record.id));
                        }}
                      >
                        <Tooltip title={'Delete'}><DeleteOutlined /></Tooltip>
                      </Popconfirm>
                    </>
                  )}
                </>
              )
            } else return <></>
          } return <></>
        },
      }
    ],
    dataSource: !isEmpty(searchedIdeas) ? searcher.search(searchedIdeas) : data,
    expandable: {
      expandedRowRender: record => <DeatilMenu record={record} />,
    },
    sticky: true,
    pagination: {
      showSizeChanger: true
    },
    scroll: {
      x: 1500,
      y: 300,
    }
  };
  return <Table {...tableProps} />
}

export default IdeaTable