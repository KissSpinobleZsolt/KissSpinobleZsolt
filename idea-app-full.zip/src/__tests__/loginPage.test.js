import { render, screen } from '@testing-library/react';
import LoginPage from '../pages/LoginPage';

test('renders learn react link', () => {
  //render(<LoginPage />);
  // eslint-disable-next-line testing-library/no-debugging-utils
  screen.debug();
  //const linkElement = screen.getByLabelText(/Email/i);
  //expect(linkElement).toBeInTheDocument();
});