steps to use
* set the config file from ./server/config.json

npm run production

all default users in db have the password: wasd

1: bbb - simple
2: bbb1 - admin
3: bbb2 - mentor
 