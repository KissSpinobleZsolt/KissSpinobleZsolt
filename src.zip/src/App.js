import { Suspense, lazy } from 'react';
import {
  Routes,
  Route,
  Outlet,
} from 'react-router-dom';
import { Spin, Layout } from 'antd';
import { Provider } from 'react-redux'
import { AuthProvider } from './api/authProvider';
import RequireAuth from './components/RequiredAuth'
import store from './redux/store';

const LoginPage = lazy(() => import('./pages/LoginPage'));
const IdeaPage = lazy(() => import('./pages/IdeaPage'));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'));
const ConfirmPage = lazy(() => import('./pages/ConfirmPage'));

function App() {
  return (
    <Provider store={store}>
      <AuthProvider>
        <Suspense fallback={<div className="inside"><Spin /></div>}>
          <Routes>
            <Route element={<Layout className="Layout" ><Outlet /></Layout>} >
              <Route index path='/' element={(
                <RequireAuth>
                  <IdeaPage />
                </RequireAuth>
              )} />
              <Route path='/login' element={<LoginPage />} />
              <Route path='/confirm' element={<ConfirmPage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Route>
          </Routes>
        </Suspense>
      </AuthProvider>
    </Provider>
  );
}

export default App;
