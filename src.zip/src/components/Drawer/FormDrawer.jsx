import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Drawer } from 'antd'
import IdeaForm from '../Form/IdeaForm'
import { toggleDrawer, selectIdeaId } from '../../redux/actions';

const FormDrawer = () => {
  const dispatch = useDispatch()
  const { visible } = useSelector(state => state.ui)
  return <Drawer
    visible={visible}
    onClose={() => {
      dispatch(toggleDrawer())
    }}
    destroyOnClose={true}
    title='Edit Idea'
    placement='left'
    width={Number(window.innerWidth) - 50}
    afterVisibleChange={isVisible => {
      !isVisible && dispatch(selectIdeaId(null))
    }}
  >
    <IdeaForm />
  </Drawer>
}

export default FormDrawer