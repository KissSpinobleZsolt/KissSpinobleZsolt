import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Drawer } from 'antd'
import UsersTable from '../Table/UsersTable'
import { toggleUserDrawer } from '../../redux/actions';

const UsersDrawer = () => {
  const dispatch = useDispatch();
  const { usersSettingsSelected } = useSelector(state => state.ui)
  return <Drawer
    visible={usersSettingsSelected}
    onClose={() => {
      dispatch(toggleUserDrawer())
    }}
    destroyOnClose={true}
    title='Edit Users Role'
    placement='right'
    width={500}
  >
    <UsersTable />
  </Drawer>
}

export default UsersDrawer