import React from 'react';
import { Layout } from 'antd'

const { Footer } = Layout;

const IdeaFooter = () => {
  return (
    <Footer className='Footer'>
       All rights reserved. Accenture Confidential. For internal use only. 
       Build version: {process.env.REACT_APP_BUILD_VERSION }
       @ 2022.05.11 
    </Footer>
  )
}

export default IdeaFooter