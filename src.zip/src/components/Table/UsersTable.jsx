import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Select, Table } from 'antd';
import { updateUserById } from '../../redux/actions';

const options = ['Simple User', 'Admin', 'Mentor'].map((label, value) => ({
  label, value
}))

const UsersTable = () => {
  const dispatch = useDispatch();
  const {
    ideas: { users }
  } = useSelector(state => state);
  return <Table {...{
    size: "large",
    bordered: true,
    columns: [{
      title: "Name",
      key: 'email',
      dataIndex: 'email'
    },
    {
      title: "Role",
      key: 'role',
      dataIndex: 'role',
      render: (value, user) => {
        return <Select {...{
          value,
          options,
          onChange: role =>
            dispatch(updateUserById({ id: user.id, role }))
        }} />
      }
    }],
    dataSource: users.map((user, key) => ({ ...user, key }))
  }} />
}

export default UsersTable