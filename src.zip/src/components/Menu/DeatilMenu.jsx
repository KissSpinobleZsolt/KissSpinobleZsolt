import React, { useState } from 'react';
import { Menu } from 'antd';
import { get, head, map } from 'lodash';
import { useSelector } from 'react-redux';
import MenuContent from './MenuContent';
import { fieldSetsKeysSelector } from '../../redux/selectors'

const DeatilMenu = ({ record }) => {
  const fieldSetsKeys = useSelector(fieldSetsKeysSelector);
  const [current, setCurrent] = useState(head(fieldSetsKeys))
  const handleClick = e => {
    setCurrent(e.key);
  };
  return (
    <>
      <Menu onClick={handleClick} selectedKeys={[current]} mode="horizontal">
        {map(fieldSetsKeys, key => {
          return (
            <Menu.Item key={key} >
              {key}
            </Menu.Item>
          )
        })}
      </Menu>
      <MenuContent currentContnet={get(record, current)} />
    </>
  )
}


export default DeatilMenu