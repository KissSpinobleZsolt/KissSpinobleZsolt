import React from 'react';
import { Button, Form, Row, Col } from 'antd';
import { useSelector, useDispatch } from 'react-redux';
import { find, get, omit } from 'lodash';
import FormItems from './FormItems'
import { updateIdea, createIdea, toggleDrawer } from '../../redux/actions';
import { userSelector } from '../../redux/selectors';

const { Item } = Form;
const sanitize = string => string === 'undefined' ? '' : string
const IdeaForm = () => {
  const dispatch = useDispatch()
  const { ideas, selectedIdeaId } = useSelector(state => state.ideas);
  const user = useSelector(userSelector);
  const idea = find(ideas, { key: selectedIdeaId });
  const onFinish = values => {
    dispatch(idea ? updateIdea({
      ...omit(idea, ['key', 'created', 'modified']),
      mentor: sanitize(values.mentor),
      ...values
    }) : createIdea({
      owner: get(user, 'id'),
      mentor: sanitize(values.mentor),
      ...values
    }))
    dispatch(toggleDrawer())
  };
  const formProps = {
    onFinish,
    layout: 'inline',
    initialValues: !idea && {
      status: "Open",
      standing: "Waiting for approval",
    },
    style: { backgroundColor: '#1890ff1f' }
  }
  return (
    <Form {...formProps} >
      <Row justify="space-around" align="middle" gutter={[8, 48]} style={{ marginTop: 32, marginBottom: 32, width: '100%' }}>
        <FormItems />
        <Col span={12} offset={12} style={{ marginTop: '4em' }}>
          <Item>
            <Button type="primary" htmlType="submit">
              {selectedIdeaId !== null ? 'Edit' : 'Create'}
            </Button>
          </Item>
        </Col>
      </Row >
    </Form>
  )
}

export default IdeaForm