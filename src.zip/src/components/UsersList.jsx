import React from 'react';
import { List } from 'antd'

const UsersList = () => {
  <List />
}

export default UsersList