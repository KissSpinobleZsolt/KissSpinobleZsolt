import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { message } from 'antd'
import { filter } from 'lodash';
import { fetchAll, fetchUpdate, fetchDelete, fetchCreate, getUsers, updateUser } from '../api/dataProvider';

export const ideaSlice = createSlice({
  name: 'idea',
  initialState: {
    ideas: [],
    selectedIdeaId: null,
    searchedIdeas: '',
    msg: null,
    users: []
  },
  reducers: {
    selectIdeaId: (state, action) => {
      state.selectedIdeaId = action.payload
    },
    updateIdeas: (state, action) => {
      state.ideas = action.payload
    },
    searchIdeas: (state, action) => {
      state.searchedIdeas = action.payload
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchIdeas.fulfilled, (state, action) => {
      state.ideas = action.payload
    });
    builder.addCase(fetchIdeas.rejected, (state, action) => {
      message.error(action.error.message)
    });
    builder.addCase(updateIdea.fulfilled, (state, action) => {
      state.ideas = action.payload
    });
    builder.addCase(updateIdea.rejected, (state, action) => {
      message.error(action.error.message)
    });
    builder.addCase(deleteIdea.fulfilled, (state, action) => {
      state.ideas = action.payload
    });
    builder.addCase(deleteIdea.rejected, (state, action) => {
      message.error(action.error.message)
    });
    builder.addCase(createIdea.fulfilled, (state, action) => {
      state.ideas = action.payload
    });
    builder.addCase(createIdea.rejected, (state, action) => {
      message.error(action.error.message)
    });
    builder.addCase(getAllUsers.fulfilled, (state, action) => {
      state.users = action.payload
    });
    builder.addCase(updateUserById.fulfilled, (state, action) => {
      state.users = action.payload
    });
  },
})

export const fetchIdeas = createAsyncThunk('ideas/fetchAll', async () => {
  const { data } = await fetchAll()
  return data
});
export const updateIdea = createAsyncThunk('ideas/fetchUpdate', async record => {
  await fetchUpdate(record)
  const { data } = await fetchAll()
  return data
});
export const deleteIdea = createAsyncThunk('ideas/fetchDelete', async id => {
  await fetchDelete(id)
  const { data } = await fetchAll()
  return data
});
export const createIdea = createAsyncThunk('ideas/fetchCreate', async record => {
  await fetchCreate(record)
  const { data } = await fetchAll()
  return data
});

export const getAllUsers = createAsyncThunk('user/all', async () => {
  const { data } = await getUsers()
  return data
})

export const updateUserById = createAsyncThunk('user/updateUser', async ({ id, role }) => {
  const { data } = await updateUser(id, role)
  return data
})
export const { selectIdeaId, searchIdeas } = ideaSlice.actions;
export const mentorsSelector = state => filter(state.ideas.users, { role: 2 })

export default ideaSlice.reducer